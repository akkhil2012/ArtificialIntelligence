# Setup Instructions for Topological Graph with Embeddings

## Quick Start

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the Application**
   ```bash
   streamlit run topological_graph_with_embeddings.py
   ```

3. **Access the UI**
   - Open your browser to `http://localhost:8501`
   - Toggle "Use Embedding DB (RAG)" to switch between embedding and REST calls

## Features

### 🧠 Embedding/RAG System
- **Pre-configured Models**: Uses `all-MiniLM-L6-v2` for all services
- **Vector Database**: ChromaDB for persistent storage
- **Test Data**: Pre-populated data for all 5 services
- **Real-time Queries**: Fast semantic search and retrieval

### 🔗 Topological Graph
- **Default Services**: configuration → Cluster Health → Build Version → Deployment Status → Monitoring
- **Dependency Management**: Add/remove dependencies through UI
- **Status Tracking**: Visual indicators for node execution status
- **Error Handling**: Automatic skipping of dependent nodes on failure

### 🎛️ Interactive Controls
- **Add/Remove Services**: Dynamic graph modification
- **Custom Prompts**: Editable prompts for each service
- **Execution Modes**: Toggle between embedding and REST calls
- **Real-time Updates**: Live status and response display

## Service Configurations

Each service has dedicated embedding models and test data:

### Configuration Service
- **Purpose**: System configuration management
- **Sample Data**: Database timeouts, load balancer settings, SSL certificates
- **Model**: all-MiniLM-L6-v2

### Cluster Health Service  
- **Purpose**: Cluster monitoring and health checks
- **Sample Data**: CPU/memory usage, network latency, disk space
- **Model**: all-MiniLM-L6-v2

### Build Version Service
- **Purpose**: Build and version management
- **Sample Data**: Current versions, release schedules, pipeline info
- **Model**: all-MiniLM-L6-v2

### Deployment Status Service
- **Purpose**: Deployment tracking and status
- **Sample Data**: Production/staging deployments, blue-green strategies
- **Model**: all-MiniLM-L6-v2

### Monitoring Service
- **Purpose**: Application monitoring and alerting
- **Sample Data**: Response times, error rates, performance metrics
- **Model**: all-MiniLM-L6-v2

## Example Queries

Try these prompts to test the embedding system:

- **Configuration**: "What is the database timeout setting?"
- **Cluster Health**: "Show me current CPU and memory usage"  
- **Build Version**: "What is the current build version?"
- **Deployment Status**: "What is the status of production deployment?"
- **Monitoring**: "Are there any performance alerts?"

## Customization

### Adding New Services
1. Add service to `SERVICE_EMBEDDING_CONFIGS` in `embedding_rag_system.py`
2. Add test data to `SERVICE_TEST_DATA`
3. Add REST URL to `SERVICE_URLS` in main app
4. Restart the application

### Changing Models
- Modify `model_name` in `SERVICE_EMBEDDING_CONFIGS`
- Different services can use different models
- Supports any HuggingFace sentence-transformer model

### Custom Test Data
- Edit `SERVICE_TEST_DATA` in `embedding_rag_system.py`
- Each item needs `id`, `content`, and `metadata` fields
- Restart to reload data

## Troubleshooting

### Common Issues

1. **ImportError: sentence-transformers**
   ```bash
   pip install sentence-transformers
   ```

2. **ChromaDB initialization failed**
   ```bash
   pip install chromadb
   # Clear any existing ChromaDB data
   rm -rf ./chroma_db
   ```

3. **CUDA/GPU Issues**
   ```bash
   # For CPU-only installation
   pip install torch --index-url https://download.pytorch.org/whl/cpu
   ```

4. **Streamlit won't start**
   ```bash
   streamlit --version
   pip install --upgrade streamlit
   ```

### Performance Tips

- First run may be slow due to model downloading
- Embedding responses are cached for faster subsequent queries
- Use `faiss-cpu` for better vector search performance
- Consider using GPU-accelerated models for production

## Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Streamlit UI  │◄──►│ ServiceGraph     │◄──►│ EmbeddingRAG    │
│                 │    │                  │    │ System          │
│ • Node Editor   │    │ • Topology       │    │                 │
│ • Prompt Input  │    │ • Dependencies   │    │ • ChromaDB      │
│ • Status View   │    │ • Execution      │    │ • Vector Search │
│ • Graph Viz     │    │ • Error Handling │    │ • Test Data     │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │
         └───────────────────────┼─────────────────────────────────┐
                                 ▼                                 ▼
                    ┌─────────────────────┐         ┌─────────────────────┐
                    │   REST API Calls    │         │   Embedding Query   │
                    │                     │         │                     │
                    │ • External Services │         │ • Semantic Search   │
                    │ • HTTP Requests     │         │ • RAG Responses     │
                    │ • Status Codes      │         │ • Local Data        │
                    └─────────────────────┘         └─────────────────────┘
```

## Next Steps

1. **Integrate Real APIs**: Replace mock URLs with actual service endpoints
2. **Add Authentication**: Implement API keys and authentication
3. **Expand Test Data**: Add more comprehensive test datasets
4. **Custom Models**: Train domain-specific embedding models
5. **Production Deployment**: Deploy with Docker and proper scaling
