# Embedding Model Integration for Topological Graph System

## Overview

I've created a comprehensive Python implementation that integrates embedding models with your topological graph system. This solution provides both **embedding-based RAG (Retrieval Augmented Generation)** and **REST API** capabilities, allowing you to toggle between them dynamically.

## Files Created

### 1. **embedding_rag_system.py** - Core Embedding System
- **EmbeddingRAGSystem Class**: Manages ChromaDB collections and embedding models
- **Service Configurations**: Pre-configured embedding models for each service
- **Test Data**: Rich test datasets for all 5 services (configuration, clusterhealth, buildversion, deploymentstatus, monitoring)
- **query_embedding_db() Function**: Main function to query embeddings with prompts

**Key Features:**
```python
# Each service has dedicated embedding configuration
SERVICE_EMBEDDING_CONFIGS = {
    "configuration": EmbeddingConfig(
        service_name="configuration", 
        model_name="all-MiniLM-L6-v2",
        collection_name="config_embeddings",
        description="Configuration management and system settings"
    ),
    # ... other services
}

# Rich test data for realistic responses
SERVICE_TEST_DATA = {
    "configuration": [
        {
            "id": "config_1",
            "content": "Database connection timeout is set to 30 seconds with retry count of 3",
            "metadata": {"type": "database", "priority": "high"}
        },
        # ... more test data
    ]
}
```

### 2. **topological_graph_with_embeddings.py** - Enhanced Streamlit App
- **Integrated UI**: Toggle between embedding DB and REST calls
- **Enhanced Visualization**: Real-time status updates with color coding
- **Dynamic Service Management**: Add/remove services and dependencies
- **Response Display**: Shows both embedding and REST responses with metadata

**Key Enhancements:**
- Toggle switch: "🧠 Use Embedding DB (RAG)" 
- Status indicators: 🔵 Pending, 🟡 Running, 🟢 Success, 🔴 Failed, 🟠 Skipped
- Real-time response display with source information (embedding vs REST)
- Enhanced error handling and dependency management

### 3. **demo_embedding_system.py** - Standalone Testing Tool
- **System Information**: Display all configured services and test data
- **Individual Testing**: Test each service with sample queries
- **Similarity Search**: Validate semantic search capabilities  
- **Edge Case Testing**: Handle errors and unusual inputs
- **Interactive Mode**: Manual testing with custom queries

### 4. **requirements.txt** - Dependencies
```
streamlit>=1.28.0
sentence-transformers>=2.2.2
chromadb>=0.4.15
networkx>=3.1
plotly>=5.15.0
# ... other dependencies
```

### 5. **SETUP.md** - Complete Setup Instructions
- Installation guide
- Usage examples  
- Troubleshooting tips
- Architecture overview
- Customization instructions

## How the Embedding System Works

### 1. **Initialization**
```python
from embedding_rag_system import setup_embedding_system, query_embedding_db

# Initialize the system (one-time setup)
setup_embedding_system()
```

### 2. **Query Function**
```python
def query_embedding_db(key: str, prompt: str) -> Optional[str]:
    """
    Query embedding database for a specific service
    
    Args:
        key: Service name (e.g., 'configuration', 'clusterhealth')
        prompt: User query/prompt
        
    Returns:
        Formatted response with similarity score and metadata
    """
```

### 3. **Integration in Your Graph**
```python
def call_mcp(service: str, prompt: str, use_embeddings: bool = False) -> MCPResponse:
    if use_embeddings and EMBEDDING_AVAILABLE:
        # Query embedding database
        cached_response = query_embedding_db(service, prompt)
        if cached_response:
            return MCPResponse(200, f"🧠 EMBEDDING: {cached_response}", latency, "embedding")
    
    # Fallback to REST API
    response = requests.get(url, params={"prompt": prompt})
    return MCPResponse(response.status_code, response.text, latency, "rest")
```

## Service-Specific Embedding Models

Each service has dedicated embedding configurations:

### Configuration Service
- **Model**: all-MiniLM-L6-v2
- **Purpose**: System configuration management
- **Sample Queries**: "What is the database timeout?", "Show SSL certificate info"
- **Test Data**: Database settings, load balancer config, SSL certificates, cache settings

### Cluster Health Service
- **Model**: all-MiniLM-L6-v2  
- **Purpose**: Cluster monitoring and diagnostics
- **Sample Queries**: "Show CPU usage", "What is the disk space status?"
- **Test Data**: Resource utilization, network latency, service mesh health

### Build Version Service
- **Model**: all-MiniLM-L6-v2
- **Purpose**: Build and version management
- **Sample Queries**: "Current build version?", "When is next release?"
- **Test Data**: Version info, release schedules, build pipeline details

### Deployment Status Service
- **Model**: all-MiniLM-L6-v2
- **Purpose**: Deployment tracking and status
- **Sample Queries**: "Production deployment status?", "Blue-green deployment info?"
- **Test Data**: Environment deployments, deployment strategies, rollback info

### Monitoring Service
- **Model**: all-MiniLM-L6-v2
- **Purpose**: Application monitoring and alerting
- **Sample Queries**: "Any performance alerts?", "Current error rate?"
- **Test Data**: Response times, error rates, performance metrics, alerts

## Quick Start Guide

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Test Embedding System
```bash
python demo_embedding_system.py
```

### 3. Run Full Application
```bash
streamlit run topological_graph_with_embeddings.py
```

### 4. Use in Browser
- Navigate to `http://localhost:8501`
- Toggle "Use Embedding DB (RAG)" to switch modes
- Add prompts and execute the graph

## Example Usage

### Embedding Queries
```python
# Configuration query
response = query_embedding_db("configuration", "What is the database timeout?")
# Returns: "🎯 Best match: Database connection timeout is set to 30 seconds..."

# Health monitoring query  
response = query_embedding_db("clusterhealth", "Show me CPU usage")
# Returns: "🎯 Best match: CPU usage is at 75%, memory utilization at 60%..."
```

### REST API Fallback
```python
# If embeddings disabled or unavailable, falls back to REST
response = call_mcp("configuration", "system config", use_embeddings=False)
# Makes HTTP request to configured REST endpoint
```

## Benefits of This Implementation

### 1. **Dual Mode Operation**
- **Embedding Mode**: Fast, semantic search with local data
- **REST Mode**: Live, authoritative data from external services
- **Dynamic Switching**: Toggle between modes without restart

### 2. **Production Ready**
- **Error Handling**: Graceful fallback on failures
- **Performance Monitoring**: Response time tracking
- **Scalable Architecture**: Supports additional services easily

### 3. **Rich Test Data**
- **Realistic Scenarios**: Production-like test data for each service
- **Metadata Support**: Rich context with each response
- **Similarity Scoring**: Confidence metrics for embedding matches

### 4. **Interactive Development**
- **Live UI**: Real-time graph visualization and status updates
- **Easy Testing**: Standalone demo script for validation
- **Flexible Configuration**: Easy to add new services and models

This comprehensive solution provides everything you need to integrate embedding models with your topological graph system while maintaining flexibility to use REST APIs when needed.