
# topological_graph_with_embeddings.py

"""
Streamlit Topological Service Graph with Embedding/RAG Integration

• Default nodes: configuration → Cluster Health → Build Version → Deployment Status → Monitoring
• Each node accepts a prompt, calls either embedding DB or REST service based on toggle
• Downstream nodes execute only if all predecessors have succeeded (200 status)
• Users can add or delete nodes and redefine dependencies on the fly
• Integrated with ChromaDB embedding system for RAG responses
"""

import time
import random
from typing import Dict, List, Optional
import networkx as nx
import plotly.graph_objects as go
import streamlit as st
from dataclasses import dataclass, field
import requests
import json

# Import the embedding system
try:
    from embedding_rag_system import embedding_system, query_embedding_db, setup_embedding_system
    EMBEDDING_AVAILABLE = True
except ImportError:
    EMBEDDING_AVAILABLE = False
    print("⚠️ Embedding system not available. Install required packages first.")

# ────────────────────────── CONFIG ──────────────────────────
# Service URL mappings for REST calls
SERVICE_URLS = {
    "configuration": "https://dummy.restapiexample.com/api/v1/employee/1",
    "clusterhealth": "https://dummy.restapiexample.com/api/v1/create", 
    "buildversion": "https://dummy.restapiexample.com/api/v1/create",
    "deploymentstatus": "https://httpbin.org/status/200",
    "monitoring": "https://httpbin.org/status/200",
}

# ───────────────────────── RESPONSE DTO ─────────────────────
@dataclass
class MCPResponse:
    status_code: int
    content: str  
    latency_ms: float
    source: str = "unknown"  # "embedding" or "rest"

# ──────────────────────── MCP ROUTING ───────────────────────
def call_mcp(service: str, prompt: str, use_embeddings: bool = False) -> MCPResponse:
    """
    Route the call to either embedding DB or REST API based on the flag

    Args:
        service: Service name
        prompt: User prompt/query
        use_embeddings: If True, query embedding DB; if False, make REST call

    Returns:
        MCPResponse with status, content, and latency
    """
    key = service.lower().replace(" ", "")
    start_time = time.time()

    # 1️⃣ Try embedding DB if enabled and available
    if use_embeddings and EMBEDDING_AVAILABLE:
        try:
            cached_response = query_embedding_db(key, prompt)
            if cached_response is not None:
                latency = (time.time() - start_time) * 1000
                return MCPResponse(
                    status_code=200,
                    content=f"🧠 EMBEDDING: {cached_response[:200]}...",
                    latency_ms=latency,
                    source="embedding"
                )
        except Exception as e:
            print(f"❌ Embedding query failed: {e}")

    # 2️⃣ Fallback to HTTP REST call
    url = SERVICE_URLS.get(key, f"http://localhost:8000/{key}")
    try:
        response = requests.get(url, params={"prompt": prompt}, timeout=10)
        latency = (time.time() - start_time) * 1000

        # For demo purposes, treat any response as success if it's from our test URLs
        if "dummy.restapiexample.com" in url or "httpbin.org" in url:
            status_code = 200
        else:
            status_code = response.status_code

        return MCPResponse(
            status_code=status_code,
            content=f"🌐 REST: {response.text[:200]}...", 
            latency_ms=latency,
            source="rest"
        )
    except requests.RequestException as e:
        latency = (time.time() - start_time) * 1000
        return MCPResponse(
            status_code=500,
            content=f"❌ Request failed: {str(e)}",
            latency_ms=latency,
            source="rest"
        )

# ────────────────────── GRAPH STRUCTURES ────────────────────
@dataclass
class ServiceNode:
    name: str
    prompt: str = ""
    status: str = "pending"  # pending | running | success | failed | skipped
    resp: Optional[MCPResponse] = None
    color: str = field(init=False, default="lightgrey")

    def update_color(self) -> None:
        color_map = {
            "pending": "lightgrey",
            "running": "gold", 
            "success": "limegreen",
            "failed": "tomato",
            "skipped": "orange"
        }
        self.color = color_map.get(self.status, "lightgrey")

class ServiceGraph:
    def __init__(self):
        self.g = nx.DiGraph()
        self.nodes: Dict[str, ServiceNode] = {}

    def add_service(self, name: str, prompt: str = "") -> None:
        """Add a new service node"""
        if name in self.nodes:
            return
        node = ServiceNode(name=name, prompt=prompt)
        self.nodes[name] = node
        self.g.add_node(name)

    def remove_service(self, name: str) -> None:
        """Remove a service node and all its connections"""
        self.nodes.pop(name, None)
        if name in self.g:
            self.g.remove_node(name)

    def add_edge(self, src: str, dst: str) -> None:
        """Add dependency edge from src to dst"""
        if src in self.g and dst in self.g and src != dst:
            self.g.add_edge(src, dst)

    def reset(self) -> None:
        """Reset all nodes to pending status"""
        for node in self.nodes.values():
            node.status = "pending"
            node.resp = None
            node.update_color()

    def can_run(self, node_name: str) -> bool:
        """Check if a node can run (all predecessors succeeded)"""
        predecessors = list(self.g.predecessors(node_name))
        return all(self.nodes[pred].status == "success" for pred in predecessors)

    def run(self, use_embeddings: bool = False) -> None:
        """Execute the graph in topological order"""
        execution_order = list(nx.topological_sort(self.g))

        for node_name in execution_order:
            node = self.nodes[node_name]

            # Skip if dependencies haven't succeeded
            if not self.can_run(node_name):
                node.status = "skipped"
                node.update_color()
                continue

            # Execute the node
            node.status = "running"
            node.update_color() 

            # Call the MCP service (embedding or REST)
            node.resp = call_mcp(node.name, node.prompt or node.name, use_embeddings)

            # Update status based on response
            if node.resp.status_code == 200:
                node.status = "success"
            else:
                node.status = "failed"
                # Mark all dependent nodes as skipped
                self._mark_dependents_as_skipped(node_name)

            node.update_color()

    def _mark_dependents_as_skipped(self, failed_node: str) -> None:
        """Mark all dependent nodes as skipped when a node fails"""
        # Get all nodes that depend on the failed node (transitively)
        dependents = set()
        for node in nx.descendants(self.g, failed_node):
            dependents.add(node)

        for dependent in dependents:
            if self.nodes[dependent].status == "pending":
                self.nodes[dependent].status = "skipped"
                self.nodes[dependent].update_color()

# ─────────────────────────── STREAMLIT UI ─────────────────────────────
def main():
    st.set_page_config(
        page_title="🔗 Topological Service Graph with RAG", 
        page_icon="🧠",
        layout="wide", 
        initial_sidebar_state="expanded"
    )

    # Initialize embedding system on first run
    if EMBEDDING_AVAILABLE and not hasattr(st.session_state, 'embedding_initialized'):
        with st.spinner("🚀 Initializing embedding system..."):
            setup_embedding_system()
        st.session_state.embedding_initialized = True
        st.success("✅ Embedding system ready!")

    # Initialize session state
    if "graph" not in st.session_state:
        sg = ServiceGraph()
        # Create default services
        default_services = [
            "configuration", 
            "Cluster Health", 
            "Build Version", 
            "Deployment Status", 
            "Monitoring"
        ]

        for service in default_services:
            sg.add_service(service)

        # Create default linear dependencies
        service_list = list(sg.nodes.keys())
        for i in range(len(service_list) - 1):
            sg.add_edge(service_list[i], service_list[i + 1])

        st.session_state.graph = sg

    sg: ServiceGraph = st.session_state.graph

    # Header
    st.title("🧠 Topological Service Graph with RAG")
    st.markdown("*Execute services in dependency order with embedding-powered responses*")

    # Sidebar Controls 
    with st.sidebar:
        st.header("⚙️ Graph Controls")

        # Embedding toggle
        use_embeddings = st.toggle(
            "🧠 Use Embedding DB (RAG)", 
            value=True,
            disabled=not EMBEDDING_AVAILABLE,
            help="Query embedding database instead of REST APIs"
        )

        if not EMBEDDING_AVAILABLE:
            st.warning("⚠️ Install sentence-transformers and chromadb to enable embeddings")

        st.divider()

        # Add new service
        with st.expander("➕ Add Service", expanded=False):
            with st.form("add_service_form"):
                new_name = st.text_input("Service Name")
                new_prompt = st.text_area("Default Prompt", height=100)
                if st.form_submit_button("Add Service") and new_name:
                    sg.add_service(new_name, new_prompt)
                    st.success(f"✅ Added {new_name}")

        # Manage dependencies
        with st.expander("🔗 Manage Dependencies", expanded=False):
            col1, col2 = st.columns(2)
            with col1:
                src = st.selectbox("Parent Service", list(sg.nodes.keys()), key="src")
            with col2:
                dst = st.selectbox("Child Service", list(sg.nodes.keys()), key="dst")

            if st.button("Add Dependency") and src and dst and src != dst:
                sg.add_edge(src, dst)
                st.success(f"✅ {src} → {dst}")

        # Remove service
        with st.expander("🗑️ Remove Service", expanded=False):
            del_name = st.selectbox("Service to Delete", [""] + list(sg.nodes.keys()))
            if st.button("Delete Service") and del_name:
                sg.remove_service(del_name)
                st.success(f"🗑️ Removed {del_name}")

        st.divider()

        # Execution controls
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🔄 Reset All", use_container_width=True):
                sg.reset()
                st.success("Reset complete!")

        with col2:
            if st.button("▶️ Run Graph", use_container_width=True):
                with st.spinner("Executing graph..."):
                    sg.run(use_embeddings)
                st.success("Execution complete!")
                st.rerun()

    # Main content area
    col1, col2 = st.columns([1, 2])

    # Left column: Service prompts
    with col1:
        st.subheader("📝 Service Prompts")

        for node_name in sg.g.nodes():
            node = sg.nodes[node_name]

            with st.expander(f"🔧 {node_name}", expanded=False):
                # Show current status
                status_colors = {
                    "pending": "🔵",
                    "running": "🟡", 
                    "success": "🟢",
                    "failed": "🔴",
                    "skipped": "🟠"
                }
                st.markdown(f"**Status:** {status_colors.get(node.status, '⚪')} {node.status.title()}")

                # Prompt input
                node.prompt = st.text_area(
                    f"Prompt for {node_name}",
                    node.prompt,
                    key=f"prompt_{node_name}",
                    height=80
                )

                # Show response if available
                if node.resp:
                    st.markdown("**Response:**")
                    st.info(f"({node.resp.source.upper()}) {node.resp.content}")
                    st.caption(f"⏱️ {node.resp.latency_ms:.1f}ms | Status: {node.resp.status_code}")

    # Right column: Graph visualization
    with col2:
        st.subheader("🗺️ Topology View")

        def draw_graph(graph: ServiceGraph) -> go.Figure:
            """Create interactive graph visualization"""
            g = graph.g
            pos = nx.spring_layout(g, seed=42, k=2, iterations=50)

            # Create edges
            edge_x, edge_y = [], []
            for src, dst in g.edges():
                x0, y0 = pos[src]
                x1, y1 = pos[dst]
                edge_x.extend([x0, x1, None])
                edge_y.extend([y0, y1, None])

            edge_trace = go.Scatter(
                x=edge_x, y=edge_y,
                mode='lines',
                line=dict(width=2, color='#888'),
                hoverinfo='none'
            )

            # Create nodes
            node_x, node_y, node_text, node_colors, hover_text = [], [], [], [], []

            for node_name in g.nodes():
                x, y = pos[node_name]
                node_x.append(x)
                node_y.append(y)

                node = graph.nodes[node_name]
                node_text.append(node_name)
                node_colors.append(node.color)

                # Create hover information
                hover_info = f"<b>{node_name}</b><br>"
                hover_info += f"Status: {node.status}<br>"
                if node.prompt:
                    hover_info += f"Prompt: {node.prompt[:50]}...<br>"
                if node.resp:
                    hover_info += f"Response: {node.resp.content[:100]}...<br>" 
                    hover_info += f"Latency: {node.resp.latency_ms:.1f}ms"

                hover_text.append(hover_info)

            node_trace = go.Scatter(
                x=node_x, y=node_y,
                mode='markers+text',
                text=node_text,
                textposition="bottom center",
                hovertext=hover_text,
                hoverinfo='text',
                marker=dict(
                    size=35,
                    color=node_colors,
                    line=dict(width=2, color='black')
                )
            )

            # Create figure
            fig = go.Figure(data=[edge_trace, node_trace])
            fig.update_layout(
                showlegend=False,
                hovermode='closest',
                margin=dict(b=20,l=5,r=5,t=40),
                annotations=[ dict(
                    text="Dependency flow: Parent → Child",
                    showarrow=False,
                    xref="paper", yref="paper",
                    x=0.005, y=-0.002,
                    xanchor="left", yanchor="bottom",
                    font=dict(color="#888", size=12)
                )],
                xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                plot_bgcolor='rgba(0,0,0,0)'
            )

            return fig

        # Display the graph
        fig = draw_graph(sg)
        st.plotly_chart(fig, use_container_width=True)

        # Status legend
        st.markdown("**Status Legend:**")
        col1, col2, col3, col4, col5 = st.columns(5)
        with col1:
            st.markdown("🔵 Pending")
        with col2:
            st.markdown("🟡 Running") 
        with col3:
            st.markdown("🟢 Success")
        with col4:
            st.markdown("🔴 Failed")
        with col5:
            st.markdown("🟠 Skipped")

if __name__ == "__main__":
    main()
