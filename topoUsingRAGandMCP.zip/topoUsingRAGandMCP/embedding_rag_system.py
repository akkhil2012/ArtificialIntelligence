
import os
import json
import time
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import numpy as np

# Uncomment these imports when packages are installed
# from sentence_transformers import SentenceTransformer
# import chromadb
# from chromadb.utils import embedding_functions

@dataclass
class EmbeddingConfig:
    """Configuration for each service's embedding model"""
    service_name: str
    model_name: str
    collection_name: str
    description: str

# Define embedding models for each service
SERVICE_EMBEDDING_CONFIGS = {
    "configuration": EmbeddingConfig(
        service_name="configuration", 
        model_name="all-MiniLM-L6-v2",
        collection_name="config_embeddings",
        description="Configuration management and system settings"
    ),
    "clusterhealth": EmbeddingConfig(
        service_name="clusterhealth",
        model_name="all-MiniLM-L6-v2", 
        collection_name="health_embeddings",
        description="Cluster health monitoring and diagnostics"
    ),
    "buildversion": EmbeddingConfig(
        service_name="buildversion",
        model_name="all-MiniLM-L6-v2",
        collection_name="build_embeddings", 
        description="Build version management and deployment info"
    ),
    "deploymentstatus": EmbeddingConfig(
        service_name="deploymentstatus",
        model_name="all-MiniLM-L6-v2",
        collection_name="deployment_embeddings",
        description="Deployment status and pipeline management" 
    ),
    "monitoring": EmbeddingConfig(
        service_name="monitoring",
        model_name="all-MiniLM-L6-v2",
        collection_name="monitoring_embeddings",
        description="System monitoring and alerting"
    )
}

# Test data for each service
SERVICE_TEST_DATA = {
    "configuration": [
        {
            "id": "config_1",
            "content": "Database connection timeout is set to 30 seconds with retry count of 3",
            "metadata": {"type": "database", "priority": "high"}
        },
        {
            "id": "config_2", 
            "content": "Load balancer configuration uses round-robin algorithm with health checks every 10 seconds",
            "metadata": {"type": "loadbalancer", "priority": "medium"}
        },
        {
            "id": "config_3",
            "content": "SSL certificate expires on 2025-12-31, auto-renewal is enabled",
            "metadata": {"type": "security", "priority": "high"}
        },
        {
            "id": "config_4",
            "content": "Cache configuration: Redis cluster with 3 nodes, TTL set to 1 hour",
            "metadata": {"type": "cache", "priority": "medium"}
        }
    ],
    "clusterhealth": [
        {
            "id": "health_1",
            "content": "CPU usage is at 75%, memory utilization at 60%, all nodes healthy",
            "metadata": {"status": "warning", "severity": "medium"}
        },
        {
            "id": "health_2",
            "content": "Network latency between nodes is 2ms, all connectivity checks passed",
            "metadata": {"status": "healthy", "severity": "low"}
        },
        {
            "id": "health_3", 
            "content": "Disk space usage: Node1 85%, Node2 45%, Node3 67% - Node1 needs attention",
            "metadata": {"status": "critical", "severity": "high"}
        },
        {
            "id": "health_4",
            "content": "Service mesh health: All 15 microservices responding, average response time 120ms",
            "metadata": {"status": "healthy", "severity": "low"}
        }
    ],
    "buildversion": [
        {
            "id": "build_1",
            "content": "Current build version: v2.4.1, built on 2025-07-30, commit hash: abc123def",
            "metadata": {"version": "2.4.1", "status": "current"}
        },
        {
            "id": "build_2",
            "content": "Previous stable version: v2.3.8, rollback available, tested on staging",
            "metadata": {"version": "2.3.8", "status": "stable"}  
        },
        {
            "id": "build_3",
            "content": "Next release v2.5.0 scheduled for August 15, includes 23 new features and 8 bug fixes",
            "metadata": {"version": "2.5.0", "status": "planned"}
        },
        {
            "id": "build_4",
            "content": "Build pipeline: 15 minutes average, includes unit tests, integration tests, and security scans",
            "metadata": {"type": "pipeline", "status": "active"}
        }
    ],
    "deploymentstatus": [
        {
            "id": "deploy_1", 
            "content": "Production deployment completed successfully at 2025-07-31 08:30 IST, 0 rollbacks",
            "metadata": {"environment": "production", "status": "success"}
        },
        {
            "id": "deploy_2",
            "content": "Staging deployment in progress: 3 of 5 services updated, ETA 10 minutes",
            "metadata": {"environment": "staging", "status": "in_progress"}
        },
        {
            "id": "deploy_3",
            "content": "Development environment: Last deployment failed due to test failures, investigating",
            "metadata": {"environment": "development", "status": "failed"}
        },
        {
            "id": "deploy_4",
            "content": "Blue-green deployment strategy active, traffic split: 80% blue, 20% green",
            "metadata": {"strategy": "blue_green", "status": "active"}
        }
    ],
    "monitoring": [
        {
            "id": "monitor_1",
            "content": "Application response time: P95 is 200ms, P99 is 450ms, SLA target is 300ms",
            "metadata": {"metric": "response_time", "status": "healthy"}
        },
        {
            "id": "monitor_2", 
            "content": "Error rate: 0.02% over last hour, threshold is 0.1%, system is stable",
            "metadata": {"metric": "error_rate", "status": "healthy"}
        },
        {
            "id": "monitor_3",
            "content": "Alert: High memory usage detected on payment service, current usage 92%",
            "metadata": {"metric": "memory", "status": "alert", "service": "payment"}
        },
        {
            "id": "monitor_4",
            "content": "Database query performance: Average 50ms, slowest query 2.1s on user analytics",
            "metadata": {"metric": "database", "status": "warning"}
        }
    ]
}

class EmbeddingRAGSystem:
    """Embedding and RAG system for topological graph services"""

    def __init__(self, persist_directory: str = "./chroma_db"):
        self.persist_directory = persist_directory
        self.models = {}
        self.client = None
        self.collections = {}
        self.initialized = False

    def initialize(self):
        """Initialize ChromaDB client and embedding models"""
        try:
            # Uncomment when chromadb is installed
            # self.client = chromadb.PersistentClient(path=self.persist_directory)
            # self.embedding_function = embedding_functions.SentenceTransformerEmbeddingFunction(
            #     model_name="all-MiniLM-L6-v2"
            # )

            print("🔧 Initializing embedding models...")
            for key, config in SERVICE_EMBEDDING_CONFIGS.items():
                # Uncomment when sentence-transformers is installed
                # self.models[key] = SentenceTransformer(config.model_name)
                print(f"✅ Loaded model for {key}: {config.model_name}")

            self.initialized = True
            print("🚀 Embedding RAG system initialized successfully!")

        except Exception as e:
            print(f"❌ Failed to initialize: {e}")
            self.initialized = False

    def create_collections(self):
        """Create ChromaDB collections for each service"""
        if not self.initialized:
            print("❌ System not initialized. Call initialize() first.")
            return

        try:
            for key, config in SERVICE_EMBEDDING_CONFIGS.items():
                # Uncomment when chromadb is installed
                # collection = self.client.get_or_create_collection(
                #     name=config.collection_name,
                #     embedding_function=self.embedding_function,
                #     metadata={"description": config.description}
                # )
                # self.collections[key] = collection
                print(f"✅ Created collection for {key}: {config.collection_name}")

        except Exception as e:
            print(f"❌ Failed to create collections: {e}")

    def populate_test_data(self):
        """Populate collections with test data"""
        if not self.collections:
            print("❌ Collections not created. Call create_collections() first.")
            return

        try:
            for service_key, test_data in SERVICE_TEST_DATA.items():
                if service_key in self.collections:
                    # collection = self.collections[service_key]

                    # Prepare data for ChromaDB
                    ids = [item["id"] for item in test_data]
                    documents = [item["content"] for item in test_data] 
                    metadatas = [item["metadata"] for item in test_data]

                    # Uncomment when chromadb is installed
                    # collection.add(
                    #     ids=ids,
                    #     documents=documents, 
                    #     metadatas=metadatas
                    # )

                    print(f"✅ Populated {len(test_data)} documents for {service_key}")

        except Exception as e:
            print(f"❌ Failed to populate test data: {e}")

    def query_embedding_db(self, key: str, prompt: str, n_results: int = 3) -> Optional[str]:
        """
        Query the embedding database for a specific service with a prompt

        Args:
            key: Service key (e.g., 'configuration', 'clusterhealth')
            prompt: User query/prompt
            n_results: Number of results to return

        Returns:
            Formatted response string or None if no results
        """
        if not self.initialized:
            return f"❌ Embedding system not initialized for service: {key}"

        # Normalize the key
        normalized_key = key.lower().replace(" ", "")

        if normalized_key not in self.collections:
            return f"❌ No embedding collection found for service: {key}"

        try:
            # collection = self.collections[normalized_key]

            # Uncomment when chromadb is installed
            # results = collection.query(
            #     query_texts=[prompt],
            #     n_results=n_results,
            #     include=["documents", "metadatas", "distances"]
            # )

            # Mock results for demonstration
            mock_results = {
                "documents": [SERVICE_TEST_DATA[normalized_key][0]["content"]],
                "metadatas": [SERVICE_TEST_DATA[normalized_key][0]["metadata"]], 
                "distances": [[0.1]]
            }

            if mock_results["documents"] and len(mock_results["documents"][0]) > 0:
                # Format the response
                best_match = mock_results["documents"][0][0]
                metadata = mock_results["metadatas"][0][0] if mock_results["metadatas"][0] else {}
                distance = mock_results["distances"][0][0]

                response = f"🎯 Best match (similarity: {1-distance:.3f}):\n{best_match}"
                if metadata:
                    response += f"\n📊 Metadata: {json.dumps(metadata, indent=2)}"

                return response
            else:
                return f"🔍 No relevant information found for '{prompt}' in {key} service"

        except Exception as e:
            return f"❌ Query failed for {key}: {str(e)}"

    def get_service_info(self, key: str) -> dict:
        """Get information about a specific service's embedding configuration"""
        normalized_key = key.lower().replace(" ", "")
        if normalized_key in SERVICE_EMBEDDING_CONFIGS:
            config = SERVICE_EMBEDDING_CONFIGS[normalized_key]
            return {
                "service": config.service_name,
                "model": config.model_name,
                "collection": config.collection_name,
                "description": config.description,
                "test_data_count": len(SERVICE_TEST_DATA.get(normalized_key, []))
            }
        return {"error": f"Service {key} not found"}

# Global instance
embedding_system = EmbeddingRAGSystem()

def setup_embedding_system():
    """Setup and initialize the embedding system with test data"""
    print("🚀 Setting up Embedding RAG System...")
    embedding_system.initialize()
    embedding_system.create_collections() 
    embedding_system.populate_test_data()
    print("✅ Embedding RAG System setup complete!")

def query_embedding_db(key: str, prompt: str) -> Optional[str]:
    """
    Main function to query embedding database - this is what you'll call in your app
    """
    return embedding_system.query_embedding_db(key, prompt)

# Example usage and testing
if __name__ == "__main__":
    # Setup the system
    setup_embedding_system()

    # Test queries for each service
    test_queries = {
        "configuration": "What is the database timeout setting?",
        "clusterhealth": "Show me the current CPU and memory usage",
        "buildversion": "What is the current build version?", 
        "deploymentstatus": "What is the status of production deployment?",
        "monitoring": "Are there any performance alerts?"
    }

    print("\n🧪 Testing embedding queries...")
    for service, query in test_queries.items():
        print(f"\n--- Testing {service.upper()} ---")
        print(f"Query: {query}")
        response = query_embedding_db(service, query)
        print(f"Response: {response}")
