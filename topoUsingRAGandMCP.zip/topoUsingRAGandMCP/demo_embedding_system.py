
#!/usr/bin/env python3
"""
Demo script for testing the Embedding RAG System

This script demonstrates how to use the embedding system independently
of the Streamlit application for testing and validation.
"""

import sys
import time
from embedding_rag_system import (
    embedding_system, 
    query_embedding_db, 
    setup_embedding_system,
    SERVICE_EMBEDDING_CONFIGS,
    SERVICE_TEST_DATA
)

def print_banner():
    """Print a nice banner"""
    print("=" * 60)
    print("🧠 EMBEDDING RAG SYSTEM DEMO")
    print("=" * 60)
    print()

def test_system_info():
    """Display system information"""
    print("📊 SYSTEM INFORMATION")
    print("-" * 30)

    print(f"Available Services: {len(SERVICE_EMBEDDING_CONFIGS)}")
    for key, config in SERVICE_EMBEDDING_CONFIGS.items():
        print(f"  • {key.upper()}: {config.description}")

    print(f"\nTotal Test Documents: {sum(len(data) for data in SERVICE_TEST_DATA.values())}")
    for service, data in SERVICE_TEST_DATA.items():
        print(f"  • {service}: {len(data)} documents")
    print()

def test_individual_services():
    """Test each service with sample queries"""
    print("🧪 TESTING INDIVIDUAL SERVICES")
    print("-" * 35)

    test_cases = [
        ("configuration", "What is the database timeout setting?"),
        ("configuration", "Tell me about SSL certificate configuration"),
        ("clusterhealth", "Show me the current CPU and memory usage"),
        ("clusterhealth", "What is the disk space status?"),
        ("buildversion", "What is the current build version?"),
        ("buildversion", "When is the next release scheduled?"),
        ("deploymentstatus", "What is the status of production deployment?"),
        ("deploymentstatus", "Tell me about blue-green deployment"),
        ("monitoring", "Are there any performance alerts?"),
        ("monitoring", "What is the current error rate?")
    ]

    success_count = 0
    total_count = len(test_cases)

    for service, query in test_cases:
        print(f"\n🔍 Testing {service.upper()}")
        print(f"Query: '{query}'")
        print("-" * 50)

        start_time = time.time()
        try:
            response = query_embedding_db(service, query)
            query_time = (time.time() - start_time) * 1000

            if response and not response.startswith("❌"):
                print(f"✅ SUCCESS ({query_time:.1f}ms)")
                print(f"Response: {response[:150]}...")
                success_count += 1
            else:
                print(f"❌ FAILED ({query_time:.1f}ms)")
                print(f"Error: {response}")

        except Exception as e:
            query_time = (time.time() - start_time) * 1000
            print(f"💥 EXCEPTION ({query_time:.1f}ms)")
            print(f"Error: {str(e)}")

    print(f"\n📈 RESULTS: {success_count}/{total_count} tests passed ({success_count/total_count*100:.1f}%)")

def test_similarity_search():
    """Test similarity search capabilities"""
    print("\n🎯 TESTING SIMILARITY SEARCH")
    print("-" * 32)

    similarity_tests = [
        ("configuration", "database connection timeout", "Should find database timeout info"),
        ("clusterhealth", "memory and CPU utilization", "Should find resource usage info"),
        ("monitoring", "application latency", "Should find response time metrics"),
        ("deploymentstatus", "production rollout", "Should find deployment status"),
        ("buildversion", "software release", "Should find version information")
    ]

    for service, query, expected in similarity_tests:
        print(f"\n🔍 {service.upper()}: '{query}'")
        print(f"Expected: {expected}")

        start_time = time.time()
        response = query_embedding_db(service, query)
        query_time = (time.time() - start_time) * 1000

        if response and not response.startswith("❌"):
            print(f"✅ Found relevant content ({query_time:.1f}ms)")
            # Extract just the content part for readability
            content = response.split(":\n")[1].split("\n📊")[0] if ":\n" in response else response
            print(f"Match: {content[:100]}...")
        else:
            print(f"❌ No relevant content found ({query_time:.1f}ms)")

def test_edge_cases():
    """Test edge cases and error handling"""
    print("\n🚨 TESTING EDGE CASES")
    print("-" * 25)

    edge_cases = [
        ("nonexistent_service", "test query", "Should handle unknown service"),
        ("configuration", "", "Should handle empty query"),
        ("monitoring", "completely unrelated query about cooking recipes", "Should handle irrelevant queries"),
        ("", "test query", "Should handle empty service name")
    ]

    for service, query, expected in edge_cases:
        print(f"\n🧪 Edge Case: service='{service}', query='{query[:30]}...'")
        print(f"Expected: {expected}")

        try:
            start_time = time.time()
            response = query_embedding_db(service, query)
            query_time = (time.time() - start_time) * 1000

            print(f"Result ({query_time:.1f}ms): {response[:80]}...")

        except Exception as e:
            print(f"Exception handled: {str(e)[:80]}...")

def interactive_mode():
    """Interactive testing mode"""
    print("\n🎮 INTERACTIVE MODE")
    print("-" * 20)
    print("Type 'quit' to exit, 'help' for commands")
    print("Available services:", ", ".join(SERVICE_EMBEDDING_CONFIGS.keys()))

    while True:
        print("\n" + "─" * 50)
        try:
            service = input("🏷️  Service name: ").strip().lower()

            if service == 'quit':
                break
            elif service == 'help':
                print("Commands:")
                print("  • Enter service name and query to test")
                print("  • 'quit' - Exit interactive mode")  
                print("  • 'help' - Show this help")
                print("  • 'list' - Show available services")
                continue
            elif service == 'list':
                print("Available services:")
                for key, config in SERVICE_EMBEDDING_CONFIGS.items():
                    print(f"  • {key}: {config.description}")
                continue

            query = input("❓ Query: ").strip()

            if not query:
                print("❌ Please enter a query")
                continue

            print("\n🔍 Searching...")
            start_time = time.time()
            response = query_embedding_db(service, query)
            query_time = (time.time() - start_time) * 1000

            print(f"\n⏱️  Query time: {query_time:.1f}ms")
            print(f"📝 Response:\n{response}")

        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"❌ Error: {e}")

def main():
    """Main demo function"""
    print_banner()

    # Initialize the system
    print("🚀 INITIALIZING EMBEDDING SYSTEM")
    print("-" * 35)
    try:
        setup_embedding_system()
        print("✅ System initialized successfully!\n")
    except Exception as e:
        print(f"❌ Failed to initialize system: {e}")
        print("Make sure you have installed the required packages:")
        print("pip install sentence-transformers chromadb")
        return

    # Run tests
    test_system_info()
    test_individual_services()
    test_similarity_search()
    test_edge_cases()

    # Interactive mode
    while True:
        choice = input("\n🎯 Start interactive mode? (y/n): ").strip().lower()
        if choice == 'y':
            interactive_mode()
            break
        elif choice == 'n':
            print("\n✅ Demo completed! Thank you for testing.")
            break
        else:
            print("Please enter 'y' or 'n'")

if __name__ == "__main__":
    main()
